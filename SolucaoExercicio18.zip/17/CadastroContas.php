
<html lang="en">
 <?php require_once('Cabecalho.php'); ?>
 <?php require_once('Conexao.php');  ?>

<?php 
    /*
      codigo utilizado para buscar um registro se for atualizar ou deixar o form em branco
      se for inserir
    */

    if(isset($_POST['id'])) {   // se existe posição id no vetor $_POST
        $id = $_POST['id'];     // arquivo foi chamado pelo form da listagem
    } else {
        $id = 0;                // arquivo não foi chamado pelo form da listagem e sim pelo botao novo
    }
    $sql = "select * from conta where id=?"; // seleciona o registro pelo id
    $sqlprep = $conexao->prepare($sql);
    $sqlprep->bind_param("i", $id);          
    $sqlprep->execute();
    $resultadoSql = $sqlprep->get_result(); // pega o resultado do sql
    $vetorUmRegistro = $resultadoSql->fetch_assoc(); // coloca o primeiro e único registro na variavel

?>
      

  <body>
            <div class="panel panel-default">
                
                <div class="panel-body">
<!-- atencao ao action do formulario  -->  
                    <form action="SalvarConta.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="id">Id</label>
<!-- importante usar o value do input para adicionar o valor recuperado do BD -->
                            <input type="text" class="form-control" id="id" name="id" placeholder="(automático)" readonly="true" value="<?=$vetorUmRegistro['id'];?>">
                        </div>
<!-- atencao ao atributo name dos inputs  -->   
                        <div class="form-group">
                            <label for="nome">Descricao</label>
                            <input type="text" class="form-control" id="nome" name="descricao" value="<?=$vetorUmRegistro['descricao'];?>">
                        </div>
                          <div class="form-group">
                            <label for="descricao">Valor</label>
                             <input type="text" class="form-control" id="endereco" name="valor" value="<?=$vetorUmRegistro['valor'];?>">
                        </div>
                        <div class="form-group">
                            <label for="descricao">Mes</label>
                             <input type="text" class="form-control" id="endereco" name="mes" value="<?=$vetorUmRegistro['mes'];?>">
                        </div>
                        <div class="form-group">
                            <label for="descricao">Ano</label>
                             <input type="text" class="form-control" id="telefone" name="ano" value="<?=$vetorUmRegistro['ano'];?>">
                        </div>
                        
                        <!--  arquivo foto-->
                        <div class="form-group">
                            <label for="foto">Foto</label>
                             <input type="file" class="form-control" id="foto" 
                                    name="foto">
                             <div class="row">
                                <img class="col-md-0 img-responsive" 
                                     src="<?=$vetorUmRegistro['foto'];?>">
                                </img>                            
                             </div>
                        </div>
                    <div class="form-group">
                            <label>Tipo de Conta:</label>
                        <select id="conta" name="conta">
                            <option value="1">Pagar</option>
                            <option value="2">Receber</option>
                        </select>
                    </div>               
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    </form>
                </div>
            </div>
    
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-9">
            <div class="row">
              <div class="col-md-3">
                <h2 class="footer-heading mb-4">Quick Links</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div>
              <div class="col-md-3">
                <h2 class="footer-heading mb-4">Products</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div>
              <div class="col-md-3">
                <h2 class="footer-heading mb-4">Features</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div>
              <div class="col-md-3">
                <h2 class="footer-heading mb-4">Follow Us</h2>
                <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
            <form action="#" method="post">
              <div class="input-group mb-3">
                <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                <div class="input-group-append">
                  <button class="btn btn-primary text-white" type="button" id="button-addon2">Send</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/rangeslider.min.js"></script>
  

  <script src="js/typed.js"></script>
            <script>
            var typed = new Typed('.typed-words', {
            strings: ["Appartments"," Restaurants"," Hotels", " Events"],
            typeSpeed: 80,
            backSpeed: 80,
            backDelay: 4000,
            startDelay: 1000,
            loop: true,
            showCursor: true
            });
            </script>

  <script src="js/main.js"></script>


    
    
  </body>
</html>