<?php 
	//pegar id do aluno que será removido
	$id = $_POST["id"];
	
    require_once('Conexao.php');
	$sql = "delete from conta where id = ?";
	$sqlprep = $conexao->prepare($sql);
	$sqlprep->bind_param("i", $id);            
	$sqlprep->execute();
	$msgOk = "Conta removida com sucesso.";
    
?>
<?php header('location: ListaContas.php?msgOk='.$msgOk); ?>