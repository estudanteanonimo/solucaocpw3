<?php 
    require_once('Conexao.php');
    $pesquisa="";                                               //cria uma variavel $pesquisa para o value do form pesquisa
    if(isset($_POST["pesquisa"])) {                                 // se veio algo do form de pesquisa
        $pesquisa = $_POST["pesquisa"];                             // pega o valor que veio do form pesquisa
        if(strstr($pesquisa,'/')==true) {
            $sql = "select * from conta where mes=? and ano=? order by ano,mes"; //instrucao sql que sera executada        
            $mesEAno=explode('/',$pesquisa);            
            $sqlprep = $conexao->prepare($sql);                         //prepara sql
            $sqlprep->bind_param("ii", $mesEAno[0],$mesEAno[1]);                   //atribui parametros ao sql
            $sqlprep->execute();                                        //executa o sql
            $resultadoSql = $sqlprep->get_result();                     //pega o resultado do sql                       
        } else {
            $pesquisaLike = "%" . $pesquisa . "%";                      // concatena caracteres %
            $sql = "select * from conta where descricao like ? order by ano,mes"; //instrucao sql que sera executada        
            $sqlprep = $conexao->prepare($sql);                         //prepara sql
            $sqlprep->bind_param("s", $pesquisaLike);                   //atribui parametros ao sql
            $sqlprep->execute();                                        //executa o sql
            $resultadoSql = $sqlprep->get_result();                     //pega o resultado do sql           
        }
    } else {                                                        //se nao veio nada do form pesquisa
        $sql = "select * from conta order by ano,mes";                //instrucao sql para todos os alunos
        $resultadoSql = $conexao->query($sql);               //executa instrucao sql e salva o resultado do sql
    }
    $vetorRegistros = $resultadoSql->fetch_all(MYSQLI_ASSOC); // pega todos os registros e coloca em um vetor de registros
 ?>        


<?php require_once('Cabecalho.php'); ?>


<?php  if(isset($msgOk)) :?>

    <div class="bg-success">   

    <?=$msgOk; ?>

    </div>
    
<?php endif ?>   
<body>
<div class="panel-body">        
   
        <div class="col-md-8">
<!-- form pesquisa -->
            <form action="ListaContas.php" 
                    method="post" 
                    class="form-inline text-right">
                <div class="form-group">
                    <label class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" for="descricao">                                  <br></label>
                     <input type="text" class="form-control" 
                            id="pesquisa" name="pesquisa" placeholder="Pesquisa por nome"
                            value="<?=$pesquisa; ?>">
                    <button type="submit" class="btn btn-primary">Pesquisar</button>
                </div>      
            </form>
<!-- fim form pesquisa -->
        </div>    
</div>
        <div class="panel-body" >
                    <table id="idTabela" class="table table-striped">
                      <thead >
                        <tr>
                          <th class="col-md-0">Foto</th>
                          <th>id</th>
                          <th>Descricao</th>
                          <th>Valor</th>
                            <th>Mes</th>
                            <th>Ano</th>
                            <th>Tipo</th>
                          <th>Alterar</th>
                          <th>Remover</th>                          
                        </tr>
                      </thead>
                      <tbody>
                          <?php $totalAReceber=0; ?>
                          <?php $totalAPagar=0; ?>
                          
                        <?php 
                          foreach($vetorRegistros as $umRegistro):
                          
                              if($umRegistro["opt"] < 2){
                                  $totalAReceber = $totalAReceber+$umRegistro["valor"];
                              } else {
                                $totalAPagar = $totalAPagar+$umRegistro["valor"];
                              }
                         ?>  
                        <tr>
                            <td> 
                                <img src="<?=$umRegistro["foto"];?>" 
                                     class="img-responsive" width="300px" height="100">
                                </img> 
                            </td>
                            <th> <?=$umRegistro["id"];?> </th>
                            <td> <?=$umRegistro["descricao"];?> </td>              
                            <td id="valor"> <?=$umRegistro["valor"];?> </td>
                            <td> <?=$umRegistro["mes"];?> </td>
                            <td> <?=$umRegistro["ano"];?> </td>
                            <td id="cont"> <?=$umRegistro["opt"];?></td>
                            <td>
                                <form action="CadastroContas.php" method="post">
                                    <input type="hidden" name="id" value="<?=$umRegistro["id"];?>">
                                    <button type="submit" class="btn btn-success">Alterar</button>
                                </form>
                            </td>                            
                            <td>
                                <form action="RemoverConta.php" method="post">
                                    <input type="hidden" name="id" value="<?=$umRegistro["id"];?>">
                                    <button type="submit" onclick="confirmaDelete()" class="btn btn-danger">Remover</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach ?>
                      </tbody>                      
                    </table>
                </div> 
<p>Total a Pagar: <?php echo $totalAPagar ?></p>
<br>
<p>Total a Receber: <?php echo $totalAReceber ?></p>
<div>
    <br
         ></div>

<?php require_once('Rodape.php'); ?>
  <!-- Footer -->
<footer id="contact" class="footer text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Localização</h4>
          <p class="lead mb-0">Weyner Company 2215 
            <br>Coxim, MS 79400-000</p>
        </div>
        <div class="col-md-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Pela Web</h4>
          <ul class="list-inline mb-0">
            <li class="list-inline-item">
              <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                <i class="fab fa-fw fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                <i class="fab fa-fw fa-google-plus-g"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                <i class="fab fa-fw fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                <i class="fab fa-fw fa-linkedin-in"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn btn-outline-light btn-social text-center rounded-circle" href="#">
                <i class="fab fa-fw fa-dribbble"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="col-md-4">
          <h4 class="text-uppercase mb-4">Sobre</h4>
          <p class="lead mb-0">Sistema de inserção/alteração de contas a pagar.
        </div>
      </div>
    </div>
  </footer>

  <div class="copyright py-4 text-center text-white">
    <div class="container">
      <small>Copyright &copy; Weyner Company 2019</small>
    </div>
  </div>
  <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
  <div class="scroll-to-top d-lg-none position-fixed ">
    <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
      <i class="fa fa-chevron-up"></i>
    </a>
  </div>

  <!-- Portfolio Modals -->

  <!-- Portfolio Modal 1 -->
  <div class="portfolio-modal mfp-hide" id="portfolio-modal-1">
    <div class="portfolio-modal-dialog bg-white">
      <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
        <i class="fa fa-3x fa-times"></i>
      </a>
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
            <hr class="star-dark mb-5">
            <img class="img-fluid mb-5" src="img/portfolio/cabin.png" alt="">
            <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
            <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
              <i class="fa fa-close"></i>
              Close Project</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Portfolio Modal 2 -->
  <div class="portfolio-modal mfp-hide" id="portfolio-modal-2">
    <div class="portfolio-modal-dialog bg-white">
      <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
        <i class="fa fa-3x fa-times"></i>
      </a>
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
            <hr class="star-dark mb-5">
            <img class="img-fluid mb-5" src="img/portfolio/cake.png" alt="">
            <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
            <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
              <i class="fa fa-close"></i>
              Close Project</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Portfolio Modal 3 -->
  <div class="portfolio-modal mfp-hide" id="portfolio-modal-3">
    <div class="portfolio-modal-dialog bg-white">
      <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
        <i class="fa fa-3x fa-times"></i>
      </a>
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
            <hr class="star-dark mb-5">
            <img class="img-fluid mb-5" src="img/portfolio/circus.png" alt="">
            <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
            <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
              <i class="fa fa-close"></i>
              Close Project</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Portfolio Modal 4 -->
  <div class="portfolio-modal mfp-hide" id="portfolio-modal-4">
    <div class="portfolio-modal-dialog bg-white">
      <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
        <i class="fa fa-3x fa-times"></i>
      </a>
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
            <hr class="star-dark mb-5">
            <img class="img-fluid mb-5" src="img/portfolio/game.png" alt="">
            <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
            <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
              <i class="fa fa-close"></i>
              Close Project</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Portfolio Modal 5 -->
  <div class="portfolio-modal mfp-hide" id="portfolio-modal-5">
    <div class="portfolio-modal-dialog bg-white">
      <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
        <i class="fa fa-3x fa-times"></i>
      </a>
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
            <hr class="star-dark mb-5">
            <img class="img-fluid mb-5" src="img/portfolio/safe.png" alt="">
            <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
            <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
              <i class="fa fa-close"></i>
              Close Project</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Portfolio Modal 6 -->
  <div class="portfolio-modal mfp-hide" id="portfolio-modal-6">
    <div class="portfolio-modal-dialog bg-white">
      <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
        <i class="fa fa-3x fa-times"></i>
      </a>
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
            <hr class="star-dark mb-5">
            <img class="img-fluid mb-5" src="img/portfolio/submarine.png" alt="">
            <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
            <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
              <i class="fa fa-close"></i>
              Close Project</a>
          </div>
        </div>
      </div>
    </div>
  </div>
<script>
function ContadorPagar(){
var tabela = document.getElementById('idTabela');
var linhas = document.getElementsById('cont');
var valor = document.getElementById('valor');
var x;
    
         
       var x = valor + x;

    alert(valor);
    
}
    function confirmaDelete(){
	if(confirm("Deseja realmente excluir?")==true) {
		return true;
	} else {
		return false;
	}
}
</script>
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="js/jqBootstrapValidation.js"></script>
  <script src="js/contact_me.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/freelancer.min.js"></script>
    <script src="js/Confirmacao.js"></script>

</body>

</html>
