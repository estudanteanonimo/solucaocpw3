function Function() {
  confirm("Quer mesmo remover este item?");
}