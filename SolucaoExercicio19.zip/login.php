<?php
    require_once('Cabecalho.php');
    require_once('Conexao.php'); 

    $email = $_POST["email"];
    $senha = $_POST["senha"];

     $sql = "select * from usuarios where email=? and senha=?"; //instrucao sql que sera executada        
        $sqlprep = $conexao->prepare($sql);                         //prepara sql
        $sqlprep->bind_param("ss", $email,$senha);                   //atribui parametros ao sql
        $sqlprep->execute();                                        //executa o sql
        $resultadoSql = $sqlprep->get_result();  
        
        $vetorRegistros = $resultadoSql->fetch_all(MYSQLI_ASSOC); // pega todos os registros e coloca em um vetor de registros

    if(count($vetorRegistros)>0){
        $_SESSION["email"]=$email;
        header("location: ListaAluno.php");
    }else{
        $_SESSION["errologin"]="erro de login ou senha.";
        header("location: FormLogin.php");
    }
?>