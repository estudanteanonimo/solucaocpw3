<?php 

	//variaveis com configuracoes de acesso ao bd
	$host = "localhost";
	$usuario = "root";
	$senha = "";
	$bd = "loja";
	$conexao = new mysqli($host, $usuario, $senha, $bd); //conecta no bd

?>