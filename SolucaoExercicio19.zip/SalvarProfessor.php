<?php 
	//pegar valores do formulário (indice do vetor eh igual ao atributo name no form)
	$id = $_POST["id"];
	$nome = $_POST["nome"];
	$endcurriculo = $_POST["endcurriculo"];
    $telefone = $_POST["telefone"];
    require_once('Conexao.php');

    if($id==0) { // se o id for 0 eh um novo registro (insert)
		$sql = "insert into professores(nome, endcurriculo, telefone) values (?,?,?)";
		$sqlprep = $conexao->prepare($sql);
		$sqlprep->bind_param("ssi", $nome, $endcurriculo, $telefone);            
		$sqlprep->execute();
		$msgOk = "Professor inserido com sucesso.";
	} else { // ser o id nao for 0 eh um atualizacao (update)
		$sql = "update professores set nome=?, endcurriculo=?, telefone=? where id=?";
		$sqlprep = $conexao->prepare($sql);
		$sqlprep->bind_param("ssi", $nome, $endcurriculo, $telefone, $id);            
		$sqlprep->execute();
		$msgOk = "Professor atualizado com sucesso.";
	}
    
?>
<?php header('location: ListaProfessor.php?msgOk='.$msgOk); ?>