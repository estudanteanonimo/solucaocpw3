<?php 
	header("location: ListaAluno.php");

	//localhost:8000/index.php = localhost:8000

?>