<?php 
	//pegar id do aluno que será removido
	$id = $_POST["id"];
	
    require_once('Conexao.php');

	$sql = "delete from disciplinas where id = ?";
	$sqlprep = $conexao->prepare($sql);
	$sqlprep->bind_param("i", $id);            
	$sqlprep->execute();

	$msgOk = "Disciplina removida com sucesso.";
    
?>
<?php header('location: ListaDisciplina.php?msgOk='.$msgOk); ?>