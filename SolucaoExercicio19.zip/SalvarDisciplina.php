<?php 
	//pegar valores do formulário (indice do vetor eh igual ao atributo name no form)
	$id = $_POST["id"];
	$nome = $_POST["nome"];
	$ementa = $_POST["ementa"];
    $chs = $_POST["chs"];
    require_once('Conexao.php');

    if($id==0) { // se o id for 0 eh um novo registro (insert)
		$sql = "insert into disciplinas(nome, ementa, chs) values (?,?,?)";
		$sqlprep = $conexao->prepare($sql);
		$sqlprep->bind_param("sss", $nome, $ementa,$chs);            
		$sqlprep->execute();
		$msgOk = "Disciplina inserida com sucesso.";
	} else { // ser o id nao for 0 eh um atualizacao (update)
		$sql = "update disciplinas set nome=?, ementa=?, chs=? where id=?";
		$sqlprep = $conexao->prepare($sql);
		$sqlprep->bind_param("sssi", $nome, $ementa, $chs, $id);            
		$sqlprep->execute();
		$msgOk = "Disciplina atualizada com sucesso.";
	}
    
?>
<?php header('location: ListaDisciplina.php?msgOk='.$msgOk); ?>