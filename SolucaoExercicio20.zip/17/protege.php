<?php
    require_once('Cabecalho.php');
    if(isset($_SESSION["email"])==false){
        $_SESSION["errologin"]="erro de login ou senha.";
        header("location: FormLogin.php");
    }
?>